# Red Button - PC edition

Desktop port of the Android "Avirbhav 2026" red-button app (Kotlin + Swing, webcam via sarxos webcam-capture).

- Click the red button (or press Space / Enter) -> webcam face-scan HUD -> FACE VERIFIED -> LOADING -> ACTIVATED
- Click / Space again after ACTIVATED to reset
- F11 = fullscreen, Esc = leave fullscreen / quit
- No webcam? The scan is simulated so the sequence still plays.

Build locally: `gradle jar` -> `build/libs/RedButton-PC.jar` (run with `java -jar`, needs Java 17+).
