package com.example.redbutton

import java.awt.Dimension
import java.awt.Frame
import java.awt.GraphicsEnvironment
import java.awt.event.WindowAdapter
import java.awt.event.WindowEvent
import javax.imageio.ImageIO
import javax.swing.JFrame
import javax.swing.SwingUtilities

fun main() {
    System.setProperty("sun.java2d.opengl", "false")
    SwingUtilities.invokeLater {
        val panel = HorrorPanel()
        val frame = JFrame("Avirbhav 2026")
        var fullscreen = false

        try {
            frame.iconImage = ImageIO.read(HorrorPanel::class.java.getResource("/icon.png"))
        } catch (ignored: Exception) {
        }

        fun toggleFullscreen() {
            val dev = GraphicsEnvironment.getLocalGraphicsEnvironment().defaultScreenDevice
            fullscreen = !fullscreen
            frame.dispose()
            frame.isUndecorated = fullscreen
            if (fullscreen) {
                dev.fullScreenWindow = frame
            } else {
                dev.fullScreenWindow = null
            }
            frame.isVisible = true
            panel.requestFocusInWindow()
        }

        panel.onToggleFullscreen = { toggleFullscreen() }
        panel.onEscape = {
            if (fullscreen) toggleFullscreen() else frame.dispatchEvent(WindowEvent(frame, WindowEvent.WINDOW_CLOSING))
        }

        frame.defaultCloseOperation = JFrame.EXIT_ON_CLOSE
        frame.addWindowListener(object : WindowAdapter() {
            override fun windowClosing(e: WindowEvent) = panel.shutdown()
            override fun windowIconified(e: WindowEvent) = panel.abortScan()
        })
        frame.contentPane.add(panel)
        panel.preferredSize = Dimension(1280, 720)
        frame.pack()
        frame.setLocationRelativeTo(null)
        frame.extendedState = Frame.MAXIMIZED_BOTH
        frame.isVisible = true
        panel.requestFocusInWindow()
    }
}
