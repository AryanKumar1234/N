package com.example.redbutton

import com.github.sarxos.webcam.Webcam
import java.awt.image.BufferedImage

/**
 * Opens the default webcam on a background thread and keeps the latest frame.
 * One instance per scan; call [stop] to release the camera.
 */
class CameraFeed {

    @Volatile var frame: BufferedImage? = null
    @Volatile var failed = false
    @Volatile private var running = true

    fun start() {
        val t = Thread({
            var cam: Webcam? = null
            try {
                cam = Webcam.getDefault() ?: throw IllegalStateException("no webcam")
                val best = cam.viewSizes
                    .filter { it.width <= 1280 }
                    .maxByOrNull { it.width * it.height }
                if (best != null) cam.viewSize = best
                cam.open()
                while (running) {
                    val img = cam.image
                    if (img != null) frame = img
                    Thread.sleep(15)
                }
            } catch (e: Throwable) {
                failed = true
            } finally {
                try { cam?.close() } catch (ignored: Throwable) {}
            }
        }, "webcam")
        t.isDaemon = true
        t.start()
    }

    fun stop() {
        running = false
    }
}
