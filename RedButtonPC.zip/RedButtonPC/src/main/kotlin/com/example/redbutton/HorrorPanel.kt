package com.example.redbutton

import java.awt.BasicStroke
import java.awt.Color
import java.awt.Cursor
import java.awt.Font
import java.awt.Graphics
import java.awt.Graphics2D
import java.awt.LinearGradientPaint
import java.awt.RadialGradientPaint
import java.awt.RenderingHints
import java.awt.TexturePaint
import java.awt.event.KeyAdapter
import java.awt.event.KeyEvent
import java.awt.event.MouseAdapter
import java.awt.event.MouseEvent
import java.awt.geom.Arc2D
import java.awt.geom.Area
import java.awt.geom.Ellipse2D
import java.awt.geom.Line2D
import java.awt.geom.Path2D
import java.awt.geom.Point2D
import java.awt.geom.Rectangle2D
import java.awt.image.BufferedImage
import java.util.Locale
import javax.swing.JPanel
import javax.swing.Timer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** A drifting dust particle (x/y are 0..1 fractions of the view). */
private class Mote(val x: Float, val y: Float, val speed: Float, val size: Float, val phase: Float)

private fun argb(a: Int, r: Int, g: Int, b: Int) =
    Color(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255), a.coerceIn(0, 255))

private fun withAlpha(c: Color, a: Int) = Color(c.red, c.green, c.blue, a.coerceIn(0, 255))

private val CLEAR = Color(0, 0, 0, 0)

/** 5x7 pixel font - just the glyphs the screen needs. */
private val GLYPHS: Map<Char, Array<String>> = mapOf(
    ' ' to arrayOf("...", "...", "...", "...", "...", "...", "..."),
    'L' to arrayOf("X....", "X....", "X....", "X....", "X....", "X....", "XXXXX"),
    'O' to arrayOf(".XXX.", "X...X", "X...X", "X...X", "X...X", "X...X", ".XXX."),
    'A' to arrayOf(".XXX.", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"),
    'D' to arrayOf("XXXX.", "X...X", "X...X", "X...X", "X...X", "X...X", "XXXX."),
    'I' to arrayOf("XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "XXXXX"),
    'N' to arrayOf("X...X", "XX..X", "XX..X", "X.X.X", "X..XX", "X..XX", "X...X"),
    'G' to arrayOf(".XXXX", "X....", "X....", "X..XX", "X...X", "X...X", ".XXXX"),
    'C' to arrayOf(".XXXX", "X....", "X....", "X....", "X....", "X....", ".XXXX"),
    'T' to arrayOf("XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "..X.."),
    'V' to arrayOf("X...X", "X...X", "X...X", "X...X", "X...X", ".X.X.", "..X.."),
    'E' to arrayOf("XXXXX", "X....", "X....", "XXXX.", "X....", "X....", "XXXXX"),
    '0' to arrayOf(".XXX.", "X...X", "X..XX", "X.X.X", "XX..X", "X...X", ".XXX."),
    '1' to arrayOf("..X..", ".XX..", "..X..", "..X..", "..X..", "..X..", ".XXX."),
    '2' to arrayOf(".XXX.", "X...X", "....X", "...X.", "..X..", ".X...", "XXXXX"),
    '3' to arrayOf("XXXX.", "....X", "....X", ".XXX.", "....X", "....X", "XXXX."),
    '4' to arrayOf("...X.", "..XX.", ".X.X.", "X..X.", "XXXXX", "...X.", "...X."),
    '5' to arrayOf("XXXXX", "X....", "XXXX.", "....X", "....X", "X...X", ".XXX."),
    '6' to arrayOf(".XXX.", "X....", "X....", "XXXX.", "X...X", "X...X", ".XXX."),
    '7' to arrayOf("XXXXX", "....X", "...X.", "..X..", ".X...", ".X...", ".X..."),
    '8' to arrayOf(".XXX.", "X...X", "X...X", ".XXX.", "X...X", "X...X", ".XXX."),
    '9' to arrayOf(".XXX.", "X...X", "X...X", ".XXXX", "....X", "....X", ".XXX."),
    'F' to arrayOf("XXXXX", "X....", "X....", "XXXX.", "X....", "X....", "X...."),
    'R' to arrayOf("XXXX.", "X...X", "X...X", "XXXX.", "X.X..", "X..X.", "X...X"),
    'S' to arrayOf(".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX."),
    'M' to arrayOf("X...X", "XX.XX", "X.X.X", "X.X.X", "X...X", "X...X", "X...X"),
    'B' to arrayOf("XXXX.", "X...X", "X...X", "XXXX.", "X...X", "X...X", "XXXX."),
    'H' to arrayOf("X...X", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"),
    ':' to arrayOf(".....", "..X..", "..X..", ".....", "..X..", "..X..", "....."),
    '%' to arrayOf("XX..X", "XX..X", "...X.", "..X..", ".X...", "X..XX", "X..XX")
)

/**
 * Whole horror loading screen drawn on one JPanel (Java2D).
 * Everything is computed from the panel's width/height, so any window size works.
 */
class HorrorPanel : JPanel() {

    private enum class State { IDLE, SCANNING, VERIFIED, LOADING, DONE }

    private var state = State.IDLE
    private var progress = 0f            // 0..1
    private var doneAt = 0L
    private var phaseStart = 0L          // when SCANNING / VERIFIED began
    private var loadStart = 0L
    private val loadMs = 5000f

    var onToggleFullscreen: () -> Unit = {}
    var onEscape: () -> Unit = {}

    // live camera scan
    private var camera: CameraFeed? = null
    private var lastTick = 0L
    private var faceLock = 0f            // 0..1, scan progress
    private val lockMs = 2500f
    private val verifiedDur = 1500L
    private var pressed = false
    private val startTime = nowMs()
    private val rnd = Random(666)

    // geometry
    private var layoutW = -1
    private var layoutH = -1
    private var cx = 0f
    private var cy = 0f
    private var radius = 1f

    // retro loading bar geometry
    private val segCount = 10
    private var barL = 0f
    private var barT = 0f
    private var barW = 0f
    private var barH = 0f
    private var bw = 0f        // frame thickness
    private var pad = 0f       // gap between frame and blocks
    private var segGap = 0f
    private var segW = 0f
    private var segH = 0f

    // paints (rebuilt whenever the size changes)
    private var bgPaint: java.awt.Paint = Color.BLACK
    private var vignettePaint: java.awt.Paint = CLEAR
    private var facePaint: java.awt.Paint = Color.RED
    private var rimPaint: java.awt.Paint = Color.DARK_GRAY
    private var shinePaint: java.awt.Paint = Color.WHITE
    private var shadePaint: java.awt.Paint = CLEAR
    private var scanlinePaint: java.awt.Paint = CLEAR
    private var motes: List<Mote> = emptyList()

    private val cyan = Color(0, 230, 255)
    private val green = Color(40, 255, 90)
    private val mono: Font = Font(Font.MONOSPACED, Font.PLAIN, 12)

    private val scanLines = arrayOf("HOLD STILL", "READING BIOMETRICS", "MATCHING IDENTITY")

    private val lines = arrayOf(
        "SOMETHING IS WAKING...",
        "IT CAN HEAR YOU...",
        "DON'T LOOK BEHIND YOU...",
        "IT'S ALMOST HERE...",
        "TOO LATE."
    )

    private val ticker = Timer(16) { repaint() }

    init {
        background = Color.BLACK
        isFocusable = true
        isOpaque = true
        ticker.start()

        val mouse = object : MouseAdapter() {
            override fun mousePressed(e: MouseEvent) {
                requestFocusInWindow()
                if (isInside(e.x.toFloat(), e.y.toFloat())) pressed = true
            }

            override fun mouseReleased(e: MouseEvent) {
                val wasPressed = pressed
                pressed = false
                if (wasPressed && isInside(e.x.toFloat(), e.y.toFloat())) activate()
            }

            override fun mouseMoved(e: MouseEvent) {
                cursor = if (isInside(e.x.toFloat(), e.y.toFloat()) &&
                    (state == State.IDLE || state == State.DONE)
                ) Cursor.getPredefinedCursor(Cursor.HAND_CURSOR) else Cursor.getDefaultCursor()
            }
        }
        addMouseListener(mouse)
        addMouseMotionListener(mouse)

        addKeyListener(object : KeyAdapter() {
            override fun keyPressed(e: KeyEvent) {
                when (e.keyCode) {
                    KeyEvent.VK_SPACE, KeyEvent.VK_ENTER -> pressed = true
                    KeyEvent.VK_F11 -> onToggleFullscreen()
                    KeyEvent.VK_ESCAPE -> onEscape()
                }
            }

            override fun keyReleased(e: KeyEvent) {
                if (e.keyCode == KeyEvent.VK_SPACE || e.keyCode == KeyEvent.VK_ENTER) {
                    val wasPressed = pressed
                    pressed = false
                    if (wasPressed) activate()
                }
            }
        })
    }

    // ---------------------------------------------------------- interaction

    private fun isInside(x: Float, y: Float): Boolean =
        state == State.DONE || hypot(x - cx, y - cy) <= radius * 1.15f

    private fun activate() {
        when (state) {
            State.IDLE -> startScan()
            State.DONE -> if (nowMs() - doneAt > 800) reset()
            else -> {}
        }
    }

    private fun startScan() {
        stopCamera()
        camera = CameraFeed().also { it.start() }
        state = State.SCANNING
        phaseStart = nowMs()
        lastTick = phaseStart
        faceLock = 0f
        progress = 0f
    }

    /** Window minimised / closed while scanning. */
    fun abortScan() {
        if (state == State.SCANNING) {
            state = State.IDLE
            faceLock = 0f
        }
        stopCamera()
    }

    fun shutdown() {
        ticker.stop()
        stopCamera()
    }

    private fun stopCamera() {
        camera?.stop()
        camera = null
    }

    private fun startLoading() {
        state = State.LOADING
        progress = 0f
        loadStart = nowMs()
    }

    private fun reset() {
        state = State.IDLE
        progress = 0f
    }

    private fun nowMs(): Long = System.nanoTime() / 1_000_000L

    // --------------------------------------------------------------- layout

    private fun relayout(w: Int, h: Int) {
        layoutW = w
        layoutH = h
        val wf = w.toFloat()
        val hf = h.toFloat()
        cx = wf / 2f
        cy = hf * 0.40f
        radius = max(8f, min(wf * 0.22f, hf * 0.20f))

        // loading bar
        barW = min(wf * 0.84f, radius * 4.6f)
        barH = radius * 0.46f
        barL = cx - barW / 2f
        barT = cy + radius * 1.5f
        bw = barH * 0.09f
        pad = barH * 0.13f
        segGap = pad * 0.8f
        val innerW = barW - 2f * (bw + pad)
        segW = (innerW - segGap * (segCount - 1)) / segCount
        segH = barH - 2f * (bw + pad)

        val diag = hypot(wf, hf)
        vignettePaint = RadialGradientPaint(
            Point2D.Float(wf / 2f, hf / 2f), diag / 2f,
            floatArrayOf(0f, 0.45f, 1f),
            arrayOf(CLEAR, CLEAR, argb(235, 0, 0, 0))
        )
        bgPaint = RadialGradientPaint(
            Point2D.Float(cx, cy), diag * 0.6f,
            floatArrayOf(0f, 0.5f, 1f),
            arrayOf(Color(38, 0, 0), Color(8, 0, 0), Color.BLACK)
        )
        facePaint = RadialGradientPaint(
            Point2D.Float(cx - radius * 0.3f, cy - radius * 0.35f), radius * 1.25f,
            floatArrayOf(0f, 0.55f, 1f),
            arrayOf(Color(255, 70, 60), Color(200, 0, 0), Color(90, 0, 0))
        )
        rimPaint = LinearGradientPaint(
            Point2D.Float(cx, cy - radius), Point2D.Float(cx, cy + radius * 1.15f),
            floatArrayOf(0f, 1f), arrayOf(Color(70, 70, 70), Color(8, 8, 8))
        )
        shinePaint = LinearGradientPaint(
            Point2D.Float(cx, cy - radius * 0.9f), Point2D.Float(cx, cy),
            floatArrayOf(0f, 1f), arrayOf(argb(150, 255, 255, 255), argb(0, 255, 255, 255))
        )
        shadePaint = LinearGradientPaint(
            Point2D.Float(0f, hf * 0.55f), Point2D.Float(0f, hf),
            floatArrayOf(0f, 1f), arrayOf(argb(0, 0, 0, 0), argb(210, 0, 0, 0))
        )
        // scanlines pre-rendered once as a tiny repeating texture
        val tile = BufferedImage(1, 5, BufferedImage.TYPE_INT_ARGB)
        val sl = argb(28, 0, 0, 0).rgb
        tile.setRGB(0, 0, sl); tile.setRGB(0, 1, sl)
        scanlinePaint = TexturePaint(tile, Rectangle2D.Float(0f, 0f, 1f, 5f))

        motes = List(40) {
            Mote(
                rnd.nextFloat(), rnd.nextFloat(), 0.01f + rnd.nextFloat() * 0.04f,
                1f + rnd.nextFloat() * 2.5f, rnd.nextFloat() * 6.28f
            )
        }
    }

    // ----------------------------------------------------------------- draw

    override fun paintComponent(g0: Graphics) {
        if (width <= 0 || height <= 0) return
        val g = g0.create() as Graphics2D
        try {
            if (width != layoutW || height != layoutH) relayout(width, height)
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
            g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON)
            g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE)
            draw(g)
        } finally {
            g.dispose()
        }
    }

    private fun cameraReady(): Boolean {
        val cam = camera ?: return false
        return cam.frame != null || cam.failed
    }

    private fun draw(g: Graphics2D) {
        val now = nowMs()
        val t = (now - startTime) / 1000f
        val w = width.toFloat()
        val h = height.toFloat()

        // scan -> verified -> loading -> done hand-over
        when (state) {
            State.SCANNING -> {
                val dt = (now - lastTick).coerceIn(0L, 100L)
                if (cameraReady()) faceLock = (faceLock + dt / lockMs).coerceIn(0f, 1f)
                if (faceLock >= 1f) {
                    state = State.VERIFIED
                    phaseStart = now
                    stopCamera()
                }
            }
            State.VERIFIED -> if (now - phaseStart >= verifiedDur) startLoading()
            State.LOADING -> {
                progress = ((now - loadStart) / loadMs).coerceIn(0f, 1f)
                if (progress >= 1f) {
                    progress = 1f
                    state = State.DONE
                    doneAt = now
                }
            }
            else -> {}
        }
        lastTick = now

        // shake grows while loading, big slam when activated
        var sx = 0f
        var sy = 0f
        val sinceDone = if (state == State.DONE) now - doneAt else Long.MAX_VALUE
        val shake = when (state) {
            State.LOADING -> progress * progress * radius * 0.05f
            State.SCANNING -> radius * 0.004f
            State.DONE -> if (sinceDone < 700) radius * 0.12f * (1f - sinceDone / 700f) else 0f
            else -> 0f
        }
        if (shake > 0f) {
            sx = (rnd.nextFloat() - 0.5f) * 2f * shake
            sy = (rnd.nextFloat() - 0.5f) * 2f * shake
        }

        // scanning: live webcam picture behind the HUD
        if (state == State.SCANNING) {
            val img = camera?.frame
            if (img != null) {
                g.color = Color.BLACK
                g.fill(Rectangle2D.Float(0f, 0f, w, h))
                drawCamera(g, img, w, h)
            } else {
                g.paint = bgPaint
                g.fill(Rectangle2D.Float(0f, 0f, w, h))
            }
            drawScan(g, now)
            return
        }

        g.paint = bgPaint
        g.fill(Rectangle2D.Float(0f, 0f, w, h))

        g.scoped {
            g.translate(sx.toDouble(), sy.toDouble())
            drawMotes(g, t, w, h)
            if (state != State.DONE) drawButton(g, t)
            when (state) {
                State.IDLE -> drawIdleText(g, t)
                State.VERIFIED -> drawVerified(g, now)
                State.LOADING -> { drawBar(g, now); drawLoadingLabel(g) }
                State.DONE -> drawActivated(g, now, sinceDone)
                else -> {}
            }
        }

        // vignette
        g.paint = vignettePaint
        g.fill(Rectangle2D.Float(0f, 0f, w, h))

        // flicker - occasional dark/red flashes, more frequent as progress rises
        val chance = when (state) {
            State.IDLE -> 0.012f
            State.LOADING -> 0.02f + progress * 0.10f
            else -> 0.015f
        }
        if (rnd.nextFloat() < chance) {
            g.color = if (rnd.nextBoolean()) argb(rnd.nextInt(60, 150), 0, 0, 0)
            else argb(rnd.nextInt(20, 60), 255, 0, 0)
            g.fill(Rectangle2D.Float(0f, 0f, w, h))
        }
        // activation flash (green, to match the text)
        if (state == State.DONE && sinceDone < 450) {
            g.color = argb((170 * (1f - sinceDone / 450f)).toInt(), 40, 255, 90)
            g.fill(Rectangle2D.Float(0f, 0f, w, h))
        }
        if (state == State.VERIFIED && now - phaseStart < 350) {
            g.color = argb((90 * (1f - (now - phaseStart) / 350f)).toInt(), 40, 255, 90)
            g.fill(Rectangle2D.Float(0f, 0f, w, h))
        }
        // scanlines
        g.paint = scanlinePaint
        g.fill(Rectangle2D.Float(0f, 0f, w, h))
    }

    /** Mirrored "selfie" webcam picture, scaled to fill (centre-crop). */
    private fun drawCamera(g: Graphics2D, img: BufferedImage, w: Float, h: Float) {
        val iw = img.width.toFloat()
        val ih = img.height.toFloat()
        val s = max(w / iw, h / ih)
        val dw = iw * s
        val dh = ih * s
        val x = (w - dw) / 2f
        val y = (h - dh) / 2f
        val old = g.getRenderingHint(RenderingHints.KEY_INTERPOLATION)
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR)
        g.drawImage(
            img,
            (x + dw).toInt(), y.toInt(), x.toInt(), (y + dh).toInt(),   // flipped horizontally
            0, 0, img.width, img.height, null
        )
        if (old != null) g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, old)
    }

    // ------------------------------------------------------------- helpers

    private inline fun Graphics2D.scoped(block: () -> Unit) {
        val tr = transform
        val cl = clip
        try {
            block()
        } finally {
            transform = tr
            clip = cl
        }
    }

    /** Hard pixel edges (retro bar / pixel font). */
    private inline fun Graphics2D.crisp(block: () -> Unit) {
        val old = getRenderingHint(RenderingHints.KEY_ANTIALIASING)
        setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF)
        try {
            block()
        } finally {
            setRenderingHint(RenderingHints.KEY_ANTIALIASING, old ?: RenderingHints.VALUE_ANTIALIAS_ON)
        }
    }

    private fun Graphics2D.rect(x: Float, y: Float, w: Float, h: Float, c: Color) {
        color = c
        fill(Rectangle2D.Float(x, y, w, h))
    }

    private fun Graphics2D.disc(x: Float, y: Float, r: Float, c: Color) {
        color = c
        fill(Ellipse2D.Float(x - r, y - r, 2f * r, 2f * r))
    }

    private fun Graphics2D.discPaint(x: Float, y: Float, r: Float, p: java.awt.Paint) {
        paint = p
        fill(Ellipse2D.Float(x - r, y - r, 2f * r, 2f * r))
    }

    private fun Graphics2D.pen(width: Float, c: Color) {
        stroke = BasicStroke(max(0.5f, width), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)
        color = c
    }

    private fun Graphics2D.ln(x1: Float, y1: Float, x2: Float, y2: Float) {
        draw(Line2D.Float(x1, y1, x2, y2))
    }

    /** Arc starting at 12 o'clock, sweeping clockwise (like Android's drawArc(-90, sweep)). */
    private fun Graphics2D.sweepArc(x: Float, y: Float, w: Float, h: Float, sweep: Float) {
        draw(Arc2D.Float(x, y, w, h, 90f, -sweep, Arc2D.OPEN))
    }

    /** Centred monospaced text with letter spacing (in em), optional dark outline. */
    private fun Graphics2D.label(
        s: String, centerX: Float, baseY: Float, size: Float, spacingEm: Float,
        c: Color, shadow: Boolean = false
    ) {
        font = mono.deriveFont(max(1f, size))
        val fm = fontMetrics
        val sp = spacingEm * size
        var total = 0f
        for (ch in s) total += fm.charWidth(ch) + sp
        var x = centerX - total / 2f
        for (ch in s) {
            val str = ch.toString()
            if (shadow) {
                color = argb(200, 0, 0, 0)
                drawString(str, x + 1f, baseY + 1f)
                drawString(str, x - 1f, baseY - 1f)
            }
            color = c
            drawString(str, x, baseY)
            x += fm.charWidth(ch) + sp
        }
    }

    // ---------------------------------------------------------------- scene

    private fun drawMotes(g: Graphics2D, t: Float, w: Float, h: Float) {
        for (m in motes) {
            val yy = ((m.y - t * m.speed) % 1f + 1f) % 1f
            val xx = m.x + sin(t * 0.6f + m.phase) * 0.02f
            val a = (40 + 40 * sin(t * 1.3f + m.phase)).toInt().coerceIn(5, 90)
            g.disc(xx * w, yy * h, m.size, argb(a, 200, 30, 20))
        }
    }

    private fun drawButton(g: Graphics2D, t: Float) {
        // heartbeat: two quick beats, faster while loading
        val bpm = when (state) {
            State.LOADING -> 70f + 110f * progress
            State.SCANNING -> 90f
            else -> 54f
        }
        val ph = (t * bpm / 60f) % 1f
        val beat = when {
            ph < 0.10f -> sin(ph / 0.10f * PI).toFloat()
            ph in 0.18f..0.30f -> 0.6f * sin((ph - 0.18f) / 0.12f * PI).toFloat()
            else -> 0f
        }
        val intensity = when (state) {
            State.IDLE -> 0.6f
            State.LOADING -> 0.8f + progress * 0.4f
            else -> 1.2f
        }
        val scale = (if (pressed) 0.93f else 1f) + beat * 0.035f

        // glow
        val gr = radius * (1.9f + beat * 0.35f)
        val glow = RadialGradientPaint(
            Point2D.Float(cx, cy), gr,
            floatArrayOf(0f, 0.55f, 1f),
            arrayOf(
                argb((170 * intensity).toInt(), 255, 0, 0),
                argb((60 * intensity).toInt(), 160, 0, 0),
                CLEAR
            )
        )
        g.discPaint(cx, cy, gr, glow)

        g.scoped {
            g.translate(cx.toDouble(), cy.toDouble())
            g.scale(scale.toDouble(), scale.toDouble())
            g.translate(-cx.toDouble(), -cy.toDouble())
            // metal base
            g.discPaint(cx, cy, radius * 1.12f, rimPaint)
            g.disc(cx, cy, radius * 1.02f, Color.BLACK)
            // red face
            g.discPaint(cx, cy, radius * (if (pressed) 0.90f else 0.96f), facePaint)
            // gloss
            val rr = radius * 0.72f
            g.paint = shinePaint
            g.fill(Ellipse2D.Float(cx - rr, cy - radius * 0.88f, 2f * rr, radius * 0.70f))
        }
    }

    // ------------------------------------------------------- pixel loading bar

    /** Retro segmented bar: shakes, splits into RGB ghosts and tears into glitched slices. */
    private fun drawBar(g: Graphics2D, now: Long) {
        val loading = state == State.LOADING
        val gl = if (loading) 0.35f + progress * 0.65f else 0.2f

        g.scoped {
            // the whole bar shakes, harder as it fills
            g.translate(
                ((rnd.nextFloat() - 0.5f) * 2f * radius * 0.03f * gl).toDouble(),
                ((rnd.nextFloat() - 0.5f) * 2f * radius * 0.03f * gl).toDouble()
            )

            if (loading) {
                val split = radius * 0.05f * gl * (0.3f + rnd.nextFloat())
                g.scoped {
                    g.translate(-split.toDouble(), 0.0)
                    drawBarBody(g, now, argb(120, 0, 255, 230))
                }
                g.scoped {
                    g.translate(split.toDouble(), 0.0)
                    drawBarBody(g, now, argb(120, 255, 0, 40))
                }
            }
            drawBarBody(g, now, null)

            // torn slices knocked sideways
            if (loading && rnd.nextFloat() < 0.25f * gl) {
                repeat(1 + rnd.nextInt(2)) {
                    val by = barT + rnd.nextFloat() * barH * 0.8f
                    val bh = barH * (0.1f + rnd.nextFloat() * 0.3f)
                    val dx = (rnd.nextFloat() - 0.5f) * radius * 0.7f * gl
                    g.crisp { g.rect(barL, by, barW, bh, Color.BLACK) }
                    g.scoped {
                        g.clip(Rectangle2D.Float(barL - radius, by, barW + 2f * radius, bh))
                        g.translate(dx.toDouble(), 0.0)
                        drawBarBody(g, now, null)
                    }
                }
            }
        }
    }

    private fun drawBarBody(g: Graphics2D, now: Long, tint: Color?) {
        val white = tint ?: Color.WHITE
        val right = barL + barW
        val bottom = barT + barH

        g.crisp {
            if (tint == null) {
                g.rect(barL + bw, barT + bw, barW - 2f * bw, barH - 2f * bw, Color.BLACK)
            }
            // frame with notched corners
            g.rect(barL + bw, barT, barW - 2f * bw, bw, white)
            g.rect(barL + bw, bottom - bw, barW - 2f * bw, bw, white)
            g.rect(barL, barT + bw, bw, barH - 2f * bw, white)
            g.rect(right - bw, barT + bw, bw, barH - 2f * bw, white)

            val filled = if (state == State.DONE) segCount.toFloat() else progress * segCount
            val y0 = barT + bw + pad
            for (i in 0 until segCount) {
                val x0 = barL + bw + pad + i * (segW + segGap)
                val f = (filled - i).coerceIn(0f, 1f)

                if (f <= 0f) {
                    // faint empty slot
                    if (tint == null) g.rect(x0, y0, segW, segH, argb(30, 255, 40, 30))
                    continue
                }

                var wdt = segW
                var col = white
                var pop = 0f
                if (f < 1f) {
                    // block that is currently charging: stepped width, flickering
                    wdt = segW * (floor(f * 4f) + 1f) / 4f
                    if (tint == null && (now / 55) % 2L == 0L) col = argb(150, 255, 255, 255)
                } else if (state == State.LOADING) {
                    val d = filled - i
                    if (d < 1.6f) pop = ((1.6f - d) / 0.6f).coerceIn(0f, 1f)
                }
                val e = pop * segGap * 0.4f
                g.rect(x0 - e, y0 - e, wdt + 2f * e, segH + 2f * e, col)
            }
        }
    }

    // --------------------------------------------------------- pixel text

    private fun glyph(ch: Char): Array<String> = GLYPHS[ch] ?: GLYPHS[' ']!!

    private fun pixelWidth(s: String, u: Float): Float {
        var n = 0
        for ((i, ch) in s.withIndex()) {
            n += glyph(ch)[0].length
            if (i < s.length - 1) n += 1
        }
        return n * u
    }

    private fun drawPixelText(g: Graphics2D, s: String, left: Float, top: Float, u: Float, color: Color, grow: Float = 0f) {
        g.crisp {
            g.color = color
            var x = left
            for (ch in s) {
                val gl = glyph(ch)
                for (r in gl.indices) for (col in gl[r].indices) {
                    if (gl[r][col] == 'X') {
                        g.fill(
                            Rectangle2D.Float(
                                x + col * u - grow, top + r * u - grow,
                                u + 2f * grow, u + 2f * grow
                            )
                        )
                    }
                }
                x += (gl[0].length + 1) * u
            }
        }
    }

    private fun drawLoadingLabel(g: Graphics2D) {
        val gl = 0.35f + progress * 0.65f
        val u = radius * 0.05f
        val s = "LOADING"
        val tw = pixelWidth(s, u)
        val top = barT + barH + radius * 0.2f
        var x = cx - tw / 2f

        // twitch sideways now and then
        if (rnd.nextFloat() < 0.12f * gl) x += (rnd.nextFloat() - 0.5f) * radius * 0.25f

        if (rnd.nextFloat() > 0.05f * gl) {
            if (rnd.nextFloat() < 0.3f * gl) {
                drawPixelText(g, s, x - u * 0.8f, top, u, argb(110, 0, 255, 230))
                drawPixelText(g, s, x + u * 0.8f, top, u, argb(110, 255, 0, 40))
            }
            drawPixelText(g, s, x, top, u, Color.WHITE)
        }

        // percentage, bottom-right under the bar
        val pct = "${(progress * 100f).toInt()}%"
        val u2 = u * 0.6f
        drawPixelText(g, pct, barL + barW - pixelWidth(pct, u2), top + u * 1.2f, u2, argb(220, 255, 255, 255))

        // creepy line
        val idx = (progress * lines.size).toInt().coerceIn(0, lines.size - 1)
        g.label(lines[idx], cx, top + 7f * u + radius * 0.35f, radius * 0.15f, 0.15f, argb(200, 170, 20, 20))
    }

    private fun drawIdleText(g: Graphics2D, t: Float) {
        val flick = if (rnd.nextFloat() < 0.04f) 0.15f else 1f
        val a = ((120 + 80 * sin(t * 2f)) * flick).toInt().coerceIn(0, 255)
        g.label("DON'T PRESS", cx, cy + radius * 1.32f + radius * 0.55f, radius * 0.24f, 0.25f, argb(a, 200, 20, 20))
    }

    // ------------------------------------------------------- camera scan

    private fun drawStatus(g: Graphics2D, s: String, col: Color, alpha: Int, scale: Float = 1f) {
        val u = min(radius * 0.05f, width * 0.9f / pixelWidth(s, 1f)) * scale
        val tw = pixelWidth(s, u)
        val top = cy + radius * 1.95f
        drawPixelText(g, s, cx - tw / 2f, top, u, withAlpha(col, alpha / 4), u * 0.45f)
        drawPixelText(g, s, cx - tw / 2f, top, u, withAlpha(col, alpha))
    }

    private fun drawSubLine(g: Graphics2D, s: String, col: Color, alpha: Int) {
        g.label(
            s, cx, cy + radius * 1.95f + radius * 0.05f * 7f + radius * 0.35f,
            radius * 0.14f, 0.15f, withAlpha(col, alpha)
        )
    }

    private fun drawScan(g: Graphics2D, now: Long) {
        val w = width.toFloat()
        val h = height.toFloat()

        // ---- face guide circle with a restrained biometric-style HUD (purely visual) ----
        val t = now / 1000f
        val textTop = cy + radius * 1.95f
        val gcy = textTop * 0.52f
        val gr = min(w * 0.34f, textTop * 0.36f)
        val locked = faceLock >= 0.98f
        val accent = if (faceLock > 0.02f) green else cyan
        val wander = 1f - faceLock
        val hair = max(1.5f, radius * 0.01f)

        // dim everything outside the circle
        val circle = Ellipse2D.Float(cx - gr, gcy - gr, 2f * gr, 2f * gr)
        val outside = Area(Rectangle2D.Float(0f, 0f, w, h))
        outside.subtract(Area(circle))
        g.color = argb(140, 0, 0, 0)
        g.fill(outside)

        g.scoped {
            g.clip(circle)

            // slow, thin scan line
            val q = (now % 3200L) / 1600f
            val fr = if (q < 1f) q else 2f - q
            val sy = gcy - gr + 2f * gr * fr
            g.rect(cx - gr, sy - gr * 0.1f, 2f * gr, gr * 0.1f, withAlpha(accent, 22))
            g.pen(hair, withAlpha(accent, 120))
            g.ln(cx - gr, sy, cx + gr, sy)

            // hairline crosshair
            g.pen(hair, argb(60, 255, 255, 255))
            val gap = gr * 0.12f
            g.ln(cx - gr, gcy, cx - gap, gcy)
            g.ln(cx + gap, gcy, cx + gr, gcy)
            g.ln(cx, gcy - gr, cx, gcy - gap)
            g.ln(cx, gcy + gr, cx, gcy + gap)

            // eye regions: fixed corner brackets, small centre mark, coordinate readout
            val ex = FloatArray(2)
            val ey = FloatArray(2)
            for (k in 0..1) {
                val side = if (k == 0) -1 else 1
                val jit = (sin(t * 3.1f + k * 1.3f) + sin(t * 7.7f + k)) * gr * 0.01f * wander
                ex[k] = cx + side * gr * 0.36f + jit
                ey[k] = gcy - gr * 0.14f + (sin(t * 4.3f + k * 2.1f) + sin(t * 9.1f + k)) * gr * 0.008f * wander
                val bw2 = gr * 0.26f
                val bh = gr * 0.17f
                val bl = bw2 * 0.38f
                g.pen(hair * 1.3f, withAlpha(accent, 200))
                val l = ex[k] - bw2
                val r = ex[k] + bw2
                val tp = ey[k] - bh
                val bt = ey[k] + bh
                g.ln(l, tp, l + bl, tp); g.ln(l, tp, l, tp + bl)
                g.ln(r, tp, r - bl, tp); g.ln(r, tp, r, tp + bl)
                g.ln(l, bt, l + bl, bt); g.ln(l, bt, l, bt - bl)
                g.ln(r, bt, r - bl, bt); g.ln(r, bt, r, bt - bl)
                g.pen(hair, withAlpha(accent, 200))
                val cr = gr * 0.035f
                g.draw(Ellipse2D.Float(ex[k] - cr, ey[k] - cr, 2f * cr, 2f * cr))
                g.disc(ex[k], ey[k], hair * 1.2f, withAlpha(accent, 230))
                val nx = (ex[k] - (cx - gr)) / (2f * gr)
                val ny = (ey[k] - (gcy - gr)) / (2f * gr)
                g.label(
                    (if (k == 0) "L " else "R ") + String.format(Locale.US, "%.3f %.3f", nx, ny),
                    ex[k], tp - bh * 0.35f, radius * 0.07f, 0.05f, withAlpha(accent, 190)
                )
            }
            // inter-eye baseline
            g.pen(hair, withAlpha(accent, 90))
            g.ln(ex[0] + gr * 0.26f, ey[0], ex[1] - gr * 0.26f, ey[1])
        }

        // fine tick ring (static), heavier at the cardinal points
        g.pen(hair, argb(110, 255, 255, 255))
        for (i in 0 until 72) {
            val a = Math.toRadians((i * 5f).toDouble())
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            val r0 = gr * 1.04f
            val r1 = r0 + gr * (if (i % 18 == 0) 0.1f else if (i % 6 == 0) 0.06f else 0.03f)
            g.ln(cx + ca * r0, gcy + sa * r0, cx + ca * r1, gcy + sa * r1)
        }

        // main ring + progress
        g.pen(hair * 1.5f, argb(150, 255, 255, 255))
        g.draw(circle)
        if (faceLock > 0f) {
            g.pen(hair * 3f, green)
            g.sweepArc(cx - gr, gcy - gr, 2f * gr, 2f * gr, 360f * faceLock)
        }

        // readouts
        val ipd = 62.0f + 0.4f * sin(t * 1.9f) * wander
        g.label(
            if (locked) "TARGET LOCKED" else "ACQUIRING  " + (faceLock * 100).toInt() + "%",
            cx, gcy + gr * 0.62f, radius * 0.085f, 0.15f, withAlpha(accent, 235), shadow = true
        )
        g.label(
            String.format(Locale.US, "IPD %.1f MM", ipd),
            cx, gcy + gr * 0.78f, radius * 0.065f, 0.15f, argb(170, 255, 255, 255), shadow = true
        )

        g.paint = shadePaint
        g.fill(Rectangle2D.Float(0f, h * 0.55f, w, h * 0.45f))

        val dots = ".".repeat(((now / 350) % 4).toInt())
        val cam = camera
        if (cam != null && cam.failed) {
            drawStatus(g, "SCANNING FACE", green, 235)
            drawSubLine(g, "NO WEBCAM FOUND - SIMULATED$dots", green, 200)
        } else if (!cameraReady()) {
            drawStatus(g, "SCANNING FACE", cyan, 235)
            drawSubLine(g, "STARTING CAMERA$dots", cyan, 190)
        } else {
            drawStatus(g, "SCANNING FACE", green, 235)
            drawSubLine(g, scanLines[(faceLock * scanLines.size).toInt().coerceIn(0, scanLines.size - 1)] + dots, green, 200)
        }

        // thin progress bar
        val bw0 = w * 0.6f
        val by = min(h * 0.96f, cy + radius * 2.75f)
        g.rect(cx - bw0 / 2f, by, bw0, radius * 0.06f, argb(90, 255, 255, 255))
        g.rect(cx - bw0 / 2f, by, bw0 * faceLock, radius * 0.06f, green)
    }

    private fun drawVerified(g: Graphics2D, now: Long) {
        val since = now - phaseStart
        val r = radius
        val k = (since / 450f).coerceIn(0f, 1f)

        // oval guide + ring
        val ox = cx - r * 1.25f
        val oy = cy - r * 1.55f
        val ow = r * 2.5f
        val oh = r * 3.1f
        g.color = argb(150, 0, 30, 10)
        g.fill(Ellipse2D.Float(ox, oy, ow, oh))
        val d = r * 0.05f
        g.pen(r * 0.07f, argb(70, 255, 255, 255))
        g.draw(Ellipse2D.Float(ox - d, oy - d, ow + 2f * d, oh + 2f * d))
        g.pen(r * 0.07f, green)
        g.sweepArc(ox - d, oy - d, ow + 2f * d, oh + 2f * d, 360f)

        // check mark drawing itself inside a ring
        g.pen(r * 0.1f, withAlpha(green, 255))
        g.sweepArc(cx - r * 0.7f, cy - r * 0.7f, r * 1.4f, r * 1.4f, 360f * k)
        val tk = ((since - 250f) / 350f).coerceIn(0f, 1f)
        if (tk > 0f) {
            val x0 = cx - r * 0.33f; val y0 = cy + r * 0.02f
            val x1 = cx - r * 0.08f; val y1 = cy + r * 0.27f
            val x2 = cx + r * 0.36f; val y2 = cy - r * 0.24f
            val path = Path2D.Float()
            path.moveTo(x0, y0)
            if (tk < 0.4f) {
                val f = tk / 0.4f
                path.lineTo(x0 + (x1 - x0) * f, y0 + (y1 - y0) * f)
            } else {
                val f = (tk - 0.4f) / 0.6f
                path.lineTo(x1, y1)
                path.lineTo(x1 + (x2 - x1) * f, y1 + (y2 - y1) * f)
            }
            g.draw(path)
        }

        val sl = if (since < 350) 1.25f - 0.25f * (since / 350f) else 1f
        drawStatus(g, "FACE VERIFIED", green, (k * 255).toInt(), sl)
        drawSubLine(g, "IDENTITY CONFIRMED", green, (190 * k).toInt())
    }

    private fun glitchLine(
        g: Graphics2D, str: String, uu: Float, top: Float, jx: Float, split: Float,
        alpha: Int, r: Int, gr: Int, b: Int
    ) {
        val left = cx - pixelWidth(str, uu) / 2f + jx
        drawPixelText(g, str, left, top, uu, argb(alpha * 28 / 255, r, gr, b), uu * 1.1f)
        drawPixelText(g, str, left, top, uu, argb(alpha * 50 / 255, r, gr, b), uu * 0.5f)
        if (split > 0f) {
            drawPixelText(g, str, left - split, top, uu, argb(alpha * 130 / 255, 0, 255, 230))
            drawPixelText(g, str, left + split, top, uu, argb(alpha * 130 / 255, 255, 0, 40))
        }
        drawPixelText(g, str, left, top, uu, argb(alpha, r, gr, b))
    }

    private fun drawActivated(g: Graphics2D, now: Long, since: Long) {
        val s = "ACTIVATED"
        val w = width.toFloat()
        val h = height.toFloat()
        // sized to the screen and placed at the exact centre
        val u = min(w * 0.86f / pixelWidth(s, 1f), h * 0.2f / 7f)
        val top = (h - 7f * u) / 2f

        // slam-in scale
        val k = (since / 350f).coerceIn(0f, 1f)
        val sc = if (k < 1f) 2.2f - 1.2f * k * k * (3f - 2f * k) else 1f
        val alpha = (k * 255).toInt()

        // glitchy jitter right after activation, occasional twitch later
        var jx = 0f
        var split = 0f
        if (since < 900) {
            val d = 1f - since / 900f
            jx = (rnd.nextFloat() - 0.5f) * 2f * u * 2.5f * d
            split = u * 1.2f * d * rnd.nextFloat()
        } else if (rnd.nextFloat() < 0.02f) {
            jx = (rnd.nextFloat() - 0.5f) * 2f * u * 1.5f
            split = u * 0.8f
        }

        // "MISSION:" / "AVIRBHAV" on two lines above the main word
        val u2 = u * 0.6f
        val gap = u * 1.2f
        val topB = top - u * 3.4f - 7f * u2
        val topA = topB - gap - 7f * u2

        g.scoped {
            g.translate(w / 2.0, h / 2.0)
            g.scale(sc.toDouble(), sc.toDouble())
            g.translate(-w / 2.0, -h / 2.0)
            glitchLine(g, s, u, top, jx, split, alpha, 40, 255, 90)
            glitchLine(g, "MISSION:", u2, topA, jx, split * 0.6f, alpha, 255, 40, 40)
            glitchLine(g, "AVIRBHAV", u2, topB, jx, split * 0.6f, alpha, 40, 150, 255)
        }

        // tiny hint
        if (since > 3500) {
            g.label(
                "click anywhere to wake it again", cx, h - radius * 0.2f, radius * 0.13f, 0.2f,
                argb((60 + 40 * sin(now / 400.0)).toInt(), 200, 40, 40)
            )
        }
    }
}
