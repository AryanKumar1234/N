package com.example.redbutton

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.PointF
import android.graphics.RectF
import android.os.Bundle
import android.util.Size
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity(), ScanHost {

    private lateinit var horrorView: HorrorView
    private lateinit var detector: FaceDetector
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else Toast.makeText(this, "Camera permission is needed to scan your face", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setMinFaceSize(0.15f)
                .build()
        )
        horrorView = HorrorView(this).also { it.host = this }
        setContentView(horrorView)
        goImmersive()
    }

    // ------------------------------------------------------------ ScanHost

    override fun onScanRequested() {
        val ok = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (ok) startCamera() else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    override fun onScanStopped() {
        analysis?.clearAnalyzer()
        provider?.unbindAll()
        analysis = null
    }

    // -------------------------------------------------------------- camera

    private fun startCamera() {
        horrorView.beginScan()
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val ia = ImageAnalysis.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setResolutionStrategy(
                                ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                            ).build()
                    )
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                ia.setAnalyzer(cameraExecutor) { proxy ->
                    if (!busy.compareAndSet(false, true)) { proxy.close(); return@setAnalyzer }
                    val upright: Bitmap
                    try {
                        val raw = proxy.toBitmap()
                        val m = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
                        upright = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                    } catch (e: Exception) {
                        busy.set(false); proxy.close(); return@setAnalyzer
                    }
                    proxy.close()
                    detector.process(InputImage.fromBitmap(upright, 0))
                        .addOnSuccessListener(cameraExecutor) { found ->
                            horrorView.onFrame(upright, found.map { f ->
                                val pts = ArrayList<PointF>()
                                for (type in intArrayOf(
                                    FaceLandmark.LEFT_EYE, FaceLandmark.RIGHT_EYE, FaceLandmark.NOSE_BASE,
                                    FaceLandmark.MOUTH_LEFT, FaceLandmark.MOUTH_RIGHT, FaceLandmark.MOUTH_BOTTOM,
                                    FaceLandmark.LEFT_CHEEK, FaceLandmark.RIGHT_CHEEK
                                )) f.getLandmark(type)?.position?.let { pts.add(PointF(it.x, it.y)) }
                                FaceInfo(RectF(f.boundingBox), pts)
                            })
                        }
                        .addOnFailureListener(cameraExecutor) { horrorView.onFrame(upright, emptyList()) }
                        .addOnCompleteListener(cameraExecutor) { busy.set(false) }
                }
                analysis = ia
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, ia)
            } catch (e: Exception) {
                horrorView.abortScan()
                Toast.makeText(this, "Couldn't open the rear camera", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        onScanStopped()
        horrorView.abortScan()
        super.onStop()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        @Suppress("DEPRECATION")
        analysis?.targetRotation = windowManager.defaultDisplay.rotation
    }

    override fun onDestroy() {
        detector.close()
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    // ----------------------------------------------------------- immersive

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goImmersive()
    }

    private fun goImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }
}
