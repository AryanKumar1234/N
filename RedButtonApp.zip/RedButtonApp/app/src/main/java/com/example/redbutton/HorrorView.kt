package com.example.redbutton

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** 5x7 pixel font – just the glyphs the screen needs. */
private val GLYPHS: Map<Char, Array<String>> = mapOf(
    ' ' to arrayOf("...", "...", "...", "...", "...", "...", "..."),
    'L' to arrayOf("X....", "X....", "X....", "X....", "X....", "X....", "XXXXX"),
    'O' to arrayOf(".XXX.", "X...X", "X...X", "X...X", "X...X", "X...X", ".XXX."),
    'A' to arrayOf(".XXX.", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"),
    'D' to arrayOf("XXXX.", "X...X", "X...X", "X...X", "X...X", "X...X", "XXXX."),
    'I' to arrayOf("XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "XXXXX"),
    'N' to arrayOf("X...X", "XX..X", "XX..X", "X.X.X", "X..XX", "X..XX", "X...X"),
    'G' to arrayOf(".XXXX", "X....", "X....", "X..XX", "X...X", "X...X", ".XXXX"),
    'C' to arrayOf(".XXXX", "X....", "X....", "X....", "X....", "X....", ".XXXX"),
    'T' to arrayOf("XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "..X.."),
    'V' to arrayOf("X...X", "X...X", "X...X", "X...X", "X...X", ".X.X.", "..X.."),
    'E' to arrayOf("XXXXX", "X....", "X....", "XXXX.", "X....", "X....", "XXXXX"),
    '0' to arrayOf(".XXX.", "X...X", "X..XX", "X.X.X", "XX..X", "X...X", ".XXX."),
    '1' to arrayOf("..X..", ".XX..", "..X..", "..X..", "..X..", "..X..", ".XXX."),
    '2' to arrayOf(".XXX.", "X...X", "....X", "...X.", "..X..", ".X...", "XXXXX"),
    '3' to arrayOf("XXXX.", "....X", "....X", ".XXX.", "....X", "....X", "XXXX."),
    '4' to arrayOf("...X.", "..XX.", ".X.X.", "X..X.", "XXXXX", "...X.", "...X."),
    '5' to arrayOf("XXXXX", "X....", "XXXX.", "....X", "....X", "X...X", ".XXX."),
    '6' to arrayOf(".XXX.", "X....", "X....", "XXXX.", "X...X", "X...X", ".XXX."),
    '7' to arrayOf("XXXXX", "....X", "...X.", "..X..", ".X...", ".X...", ".X..."),
    '8' to arrayOf(".XXX.", "X...X", "X...X", ".XXX.", "X...X", "X...X", ".XXX."),
    '9' to arrayOf(".XXX.", "X...X", "X...X", ".XXXX", "....X", "....X", ".XXX."),
    'F' to arrayOf("XXXXX", "X....", "X....", "XXXX.", "X....", "X....", "X...."),
    'R' to arrayOf("XXXX.", "X...X", "X...X", "XXXX.", "X.X..", "X..X.", "X...X"),
    'S' to arrayOf(".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX."),
    '%' to arrayOf("XX..X", "XX..X", "...X.", "..X..", ".X...", "X..XX", "X..XX")
)

/**
 * Whole horror loading screen drawn on one Canvas.
 * Everything is computed from the view's width/height, so it works in
 * portrait and landscape without any extra layout files.
 */
class HorrorView(context: Context) : View(context) {

    private enum class State { IDLE, SCANNING, VERIFIED, LOADING, DONE }

    private var state = State.IDLE
    private var progress = 0f            // 0..1
    private var doneAt = 0L
    private var phaseStart = 0L          // when SCANNING / VERIFIED began
    private val scanDur = 3200L
    private val verifiedDur = 1500L
    private var pressed = false
    private val startTime = SystemClock.uptimeMillis()
    private val rnd = Random(666)

    private var animator: ValueAnimator? = null

    // geometry
    private var cx = 0f
    private var cy = 0f
    private var radius = 0f

    // retro loading bar geometry
    private val segCount = 10
    private var barL = 0f
    private var barT = 0f
    private var barW = 0f
    private var barH = 0f
    private var bw = 0f        // frame thickness
    private var pad = 0f       // gap between frame and blocks
    private var segGap = 0f
    private var segW = 0f
    private var segH = 0f

    // paints
    private val bg = Paint()
    private val vignette = Paint()
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val face = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val px = Paint()                 // crisp, non-antialiased pixels
    private val overlay = Paint()
    private val dust = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val headRect = RectF()
    private val tmpRect = RectF()

    private val cyan = Color.rgb(0, 230, 255)

    // face landmarks, in units of radius relative to the button centre
    private val landmarks = arrayOf(
        floatArrayOf(0f, -1.30f), floatArrayOf(-0.55f, -1.05f), floatArrayOf(0.55f, -1.05f),
        floatArrayOf(-0.95f, -0.2f), floatArrayOf(0.95f, -0.2f),
        floatArrayOf(-0.58f, -0.3f), floatArrayOf(-0.18f, -0.3f),
        floatArrayOf(0.18f, -0.3f), floatArrayOf(0.58f, -0.3f),
        floatArrayOf(-0.38f, -0.55f), floatArrayOf(0.38f, -0.55f),
        floatArrayOf(0f, 0.05f), floatArrayOf(0f, 0.38f),
        floatArrayOf(-0.15f, 0.38f), floatArrayOf(0.15f, 0.38f),
        floatArrayOf(-0.35f, 0.65f), floatArrayOf(0.35f, 0.65f),
        floatArrayOf(0f, 0.72f), floatArrayOf(0f, 0.95f),
        floatArrayOf(-0.8f, 0.4f), floatArrayOf(0.8f, 0.4f),
        floatArrayOf(-0.55f, 0.95f), floatArrayOf(0.55f, 0.95f),
        floatArrayOf(0f, 1.3f)
    )

    private val mono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    private class Mote(val x: Float, val y: Float, val speed: Float, val size: Float, val phase: Float)
    private var motes: List<Mote> = emptyList()

    private val scanLines = arrayOf("MAPPING FACIAL POINTS", "READING BIOMETRICS", "MATCHING IDENTITY")

    private val lines = arrayOf(
        "SOMETHING IS WAKING...",
        "IT CAN HEAR YOU...",
        "DON'T LOOK BEHIND YOU...",
        "IT'S ALMOST HERE...",
        "TOO LATE."
    )

    private val green = Color.rgb(40, 255, 90)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cx = w / 2f
        cy = h * 0.40f
        radius = min(w * 0.22f, h * 0.20f)

        // loading bar
        barW = min(w * 0.84f, radius * 4.6f)
        barH = radius * 0.46f
        barL = cx - barW / 2f
        barT = cy + radius * 1.5f
        bw = barH * 0.09f
        pad = barH * 0.13f
        segGap = pad * 0.8f
        val innerW = barW - 2f * (bw + pad)
        segW = (innerW - segGap * (segCount - 1)) / segCount
        segH = barH - 2f * (bw + pad)

        vignette.shader = RadialGradient(
            w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) / 2f,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(235, 0, 0, 0)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        bg.shader = RadialGradient(
            cx, cy, hypot(w.toFloat(), h.toFloat()) * 0.6f,
            intArrayOf(Color.rgb(38, 0, 0), Color.rgb(8, 0, 0), Color.BLACK),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        face.shader = RadialGradient(
            cx - radius * 0.3f, cy - radius * 0.35f, radius * 1.25f,
            intArrayOf(Color.rgb(255, 70, 60), Color.rgb(200, 0, 0), Color.rgb(90, 0, 0)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        rim.shader = LinearGradient(
            cx, cy - radius, cx, cy + radius * 1.15f,
            Color.rgb(70, 70, 70), Color.rgb(8, 8, 8), Shader.TileMode.CLAMP
        )
        shine.shader = LinearGradient(
            cx, cy - radius * 0.9f, cx, cy,
            Color.argb(150, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )

        motes = List(40) {
            Mote(rnd.nextFloat(), rnd.nextFloat(), 0.01f + rnd.nextFloat() * 0.04f,
                1f + rnd.nextFloat() * 2.5f, rnd.nextFloat() * 6.28f)
        }
    }

    // ---------------------------------------------------------------- touch

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val inside = state == State.DONE || hypot(e.x - cx, e.y - cy) <= radius * 1.15f
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (inside) { pressed = true; invalidate(); return true }
                return false
            }
            MotionEvent.ACTION_UP -> {
                val wasPressed = pressed
                pressed = false
                if (wasPressed && inside) {
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    when (state) {
                        State.IDLE -> startScan()
                        State.DONE -> if (SystemClock.uptimeMillis() - doneAt > 800) reset()
                        else -> {}
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { pressed = false; invalidate() }
        }
        return true
    }

    private fun startScan() {
        state = State.SCANNING
        phaseStart = SystemClock.uptimeMillis()
        progress = 0f
    }

    private fun startLoading() {
        state = State.LOADING
        progress = 0f
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 5000L
            interpolator = LinearInterpolator()
            addUpdateListener { progress = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) {
                    if (cancelled) return
                    progress = 1f
                    state = State.DONE
                    doneAt = SystemClock.uptimeMillis()
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                }
            })
            start()
        }
    }

    private fun reset() {
        animator?.cancel()
        state = State.IDLE
        progress = 0f
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    // ----------------------------------------------------------------- draw

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = (now - startTime) / 1000f
        val w = width.toFloat()
        val h = height.toFloat()

        // scan -> verified -> loading hand-over
        if (state == State.SCANNING && now - phaseStart >= scanDur) {
            state = State.VERIFIED
            phaseStart = now
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        } else if (state == State.VERIFIED && now - phaseStart >= verifiedDur) {
            startLoading()
        }

        // shake grows while loading, big slam when activated
        var sx = 0f
        var sy = 0f
        val sinceDone = if (state == State.DONE) now - doneAt else Long.MAX_VALUE
        val shake = when (state) {
            State.LOADING -> progress * progress * radius * 0.05f
            State.SCANNING -> radius * 0.004f
            State.DONE -> if (sinceDone < 700) radius * 0.12f * (1f - sinceDone / 700f) else 0f
            else -> 0f
        }
        if (shake > 0f) { sx = (rnd.nextFloat() - 0.5f) * 2f * shake; sy = (rnd.nextFloat() - 0.5f) * 2f * shake }

        c.drawRect(0f, 0f, w, h, bg)

        c.save()
        c.translate(sx, sy)

        drawMotes(c, t, w, h)
        if (state != State.DONE) drawButton(c, t)
        when (state) {
            State.IDLE -> drawIdleText(c, t)
            State.SCANNING -> drawScan(c, now)
            State.VERIFIED -> drawVerified(c, now)
            State.LOADING -> { drawBar(c, now); drawLoadingLabel(c) }
            State.DONE -> drawActivated(c, now, sinceDone)
        }
        c.restore()

        // vignette
        c.drawRect(0f, 0f, w, h, vignette)

        // flicker – occasional dark/red flashes, more frequent as progress rises
        val chance = when (state) { State.IDLE -> 0.012f; State.LOADING -> 0.02f + progress * 0.10f; else -> 0.015f }
        if (rnd.nextFloat() < chance) {
            overlay.color = if (rnd.nextBoolean()) Color.argb(rnd.nextInt(60, 150), 0, 0, 0)
            else Color.argb(rnd.nextInt(20, 60), 255, 0, 0)
            c.drawRect(0f, 0f, w, h, overlay)
        }
        // activation flash (green, to match the text)
        if (state == State.DONE && sinceDone < 450) {
            overlay.color = Color.argb((170 * (1f - sinceDone / 450f)).toInt(), 40, 255, 90)
            c.drawRect(0f, 0f, w, h, overlay)
        }
        if (state == State.VERIFIED && now - phaseStart < 350) {
            overlay.color = Color.argb((90 * (1f - (now - phaseStart) / 350f)).toInt(), 40, 255, 90)
            c.drawRect(0f, 0f, w, h, overlay)
        }
        // scanlines
        overlay.color = Color.argb(28, 0, 0, 0)
        var y = 0f
        while (y < h) { c.drawRect(0f, y, w, y + 1.5f, overlay); y += 5f }

        postInvalidateOnAnimation()
    }

    private fun drawMotes(c: Canvas, t: Float, w: Float, h: Float) {
        for (m in motes) {
            val yy = ((m.y - t * m.speed) % 1f + 1f) % 1f
            val xx = m.x + sin(t * 0.6f + m.phase) * 0.02f
            val a = (40 + 40 * sin(t * 1.3f + m.phase)).toInt().coerceIn(5, 90)
            dust.color = Color.argb(a, 200, 30, 20)
            c.drawCircle(xx * w, yy * h, m.size, dust)
        }
    }

    private fun drawButton(c: Canvas, t: Float) {
        // heartbeat: two quick beats, faster while loading
        val bpm = when (state) { State.LOADING -> 70f + 110f * progress; State.SCANNING -> 90f; else -> 54f }
        val ph = (t * bpm / 60f) % 1f
        val beat = when {
            ph < 0.10f -> sin(ph / 0.10f * PI).toFloat()
            ph in 0.18f..0.30f -> 0.6f * sin((ph - 0.18f) / 0.12f * PI).toFloat()
            else -> 0f
        }
        val intensity = when (state) { State.IDLE -> 0.6f; State.LOADING -> 0.8f + progress * 0.4f; else -> 1.2f }
        val scale = (if (pressed) 0.93f else 1f) + beat * 0.035f

        // glow
        val gr = radius * (1.9f + beat * 0.35f)
        glow.shader = RadialGradient(
            cx, cy, gr,
            intArrayOf(Color.argb((170 * intensity).toInt().coerceAtMost(255), 255, 0, 0),
                Color.argb((60 * intensity).toInt(), 160, 0, 0), Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, gr, glow)

        c.save()
        c.scale(scale, scale, cx, cy)
        // metal base
        c.drawCircle(cx, cy, radius * 1.12f, rim)
        overlay.color = Color.BLACK
        c.drawCircle(cx, cy, radius * 1.02f, overlay)
        // red face
        c.drawCircle(cx, cy, radius * (if (pressed) 0.90f else 0.96f), face)
        // gloss
        val rr = radius * 0.72f
        c.drawOval(RectF(cx - rr, cy - radius * 0.88f, cx + rr, cy - radius * 0.18f), shine)
        c.restore()
    }

    // ------------------------------------------------------- pixel loading bar

    /** Retro segmented bar: shakes, splits into RGB ghosts and tears into glitched slices. */
    private fun drawBar(c: Canvas, now: Long) {
        val loading = state == State.LOADING
        val g = if (loading) 0.35f + progress * 0.65f else 0.2f

        c.save()
        // the whole bar shakes, harder as it fills
        c.translate(
            (rnd.nextFloat() - 0.5f) * 2f * radius * 0.03f * g,
            (rnd.nextFloat() - 0.5f) * 2f * radius * 0.03f * g
        )

        if (loading) {
            val split = radius * 0.05f * g * (0.3f + rnd.nextFloat())
            c.save(); c.translate(-split, 0f)
            drawBarBody(c, now, Color.argb(120, 0, 255, 230))
            c.restore()
            c.save(); c.translate(split, 0f)
            drawBarBody(c, now, Color.argb(120, 255, 0, 40))
            c.restore()
        }
        drawBarBody(c, now, 0)

        // torn slices knocked sideways
        if (loading && rnd.nextFloat() < 0.25f * g) {
            repeat(1 + rnd.nextInt(2)) {
                val by = barT + rnd.nextFloat() * barH * 0.8f
                val bh = barH * (0.1f + rnd.nextFloat() * 0.3f)
                val dx = (rnd.nextFloat() - 0.5f) * radius * 0.7f * g
                overlay.color = Color.BLACK
                c.drawRect(barL, by, barL + barW, by + bh, overlay)
                c.save()
                c.clipRect(barL - radius, by, barL + barW + radius, by + bh)
                c.translate(dx, 0f)
                drawBarBody(c, now, 0)
                c.restore()
            }
        }
        c.restore()
    }

    private fun drawBarBody(c: Canvas, now: Long, tint: Int) {
        val white = if (tint != 0) tint else Color.WHITE
        val right = barL + barW
        val bottom = barT + barH

        if (tint == 0) {
            px.color = Color.BLACK
            c.drawRect(barL + bw, barT + bw, right - bw, bottom - bw, px)
        }
        // frame with notched corners
        px.color = white
        c.drawRect(barL + bw, barT, right - bw, barT + bw, px)
        c.drawRect(barL + bw, bottom - bw, right - bw, bottom, px)
        c.drawRect(barL, barT + bw, barL + bw, bottom - bw, px)
        c.drawRect(right - bw, barT + bw, right, bottom - bw, px)

        val filled = if (state == State.DONE) segCount.toFloat() else progress * segCount
        val y0 = barT + bw + pad
        for (i in 0 until segCount) {
            val x0 = barL + bw + pad + i * (segW + segGap)
            val f = (filled - i).coerceIn(0f, 1f)

            if (f <= 0f) {
                // faint empty slot
                if (tint == 0) {
                    px.color = Color.argb(30, 255, 40, 30)
                    c.drawRect(x0, y0, x0 + segW, y0 + segH, px)
                }
                continue
            }

            var wdt = segW
            var col = white
            var pop = 0f
            if (f < 1f) {
                // block that is currently charging: stepped width, flickering
                wdt = segW * (kotlin.math.floor(f * 4f) + 1f) / 4f
                if (tint == 0 && (now / 55) % 2L == 0L) col = Color.argb(150, 255, 255, 255)
            } else if (state == State.LOADING) {
                val d = filled - i
                if (d < 1.6f) pop = ((1.6f - d) / 0.6f).coerceIn(0f, 1f)
            }
            val e = pop * segGap * 0.4f
            px.color = col
            c.drawRect(x0 - e, y0 - e, x0 + wdt + e, y0 + segH + e, px)
        }
    }

    // --------------------------------------------------------- pixel text

    private fun glyph(ch: Char): Array<String> = GLYPHS[ch] ?: GLYPHS[' ']!!

    private fun pixelWidth(s: String, u: Float): Float {
        var n = 0
        for ((i, ch) in s.withIndex()) {
            n += glyph(ch)[0].length
            if (i < s.length - 1) n += 1
        }
        return n * u
    }

    private fun drawPixelText(c: Canvas, s: String, left: Float, top: Float, u: Float, color: Int, grow: Float = 0f) {
        px.color = color
        var x = left
        for (ch in s) {
            val g = glyph(ch)
            for (r in g.indices) for (col in g[r].indices) {
                if (g[r][col] == 'X') {
                    c.drawRect(
                        x + col * u - grow, top + r * u - grow,
                        x + (col + 1) * u + grow, top + (r + 1) * u + grow, px
                    )
                }
            }
            x += (g[0].length + 1) * u
        }
    }

    private fun drawLoadingLabel(c: Canvas) {
        val g = 0.35f + progress * 0.65f
        val u = radius * 0.05f
        val s = "LOADING"
        val tw = pixelWidth(s, u)
        val top = barT + barH + radius * 0.2f
        var x = cx - tw / 2f

        // twitch sideways now and then
        if (rnd.nextFloat() < 0.12f * g) x += (rnd.nextFloat() - 0.5f) * radius * 0.25f

        if (rnd.nextFloat() > 0.05f * g) {
            if (rnd.nextFloat() < 0.3f * g) {
                drawPixelText(c, s, x - u * 0.8f, top, u, Color.argb(110, 0, 255, 230))
                drawPixelText(c, s, x + u * 0.8f, top, u, Color.argb(110, 255, 0, 40))
            }
            drawPixelText(c, s, x, top, u, Color.WHITE)
        }

        // percentage, bottom-right under the bar
        val pct = "${(progress * 100f).toInt()}%"
        val u2 = u * 0.6f
        drawPixelText(c, pct, barL + barW - pixelWidth(pct, u2), top + u * 1.2f, u2, Color.argb(220, 255, 255, 255))

        // creepy line
        text.typeface = mono
        text.textSize = radius * 0.15f
        text.letterSpacing = 0.15f
        text.color = Color.argb(200, 170, 20, 20)
        val idx = (progress * lines.size).toInt().coerceIn(0, lines.size - 1)
        c.drawText(lines[idx], cx, top + 7f * u + radius * 0.35f, text)
        text.letterSpacing = 0f
    }

    private fun drawIdleText(c: Canvas, t: Float) {
        text.typeface = mono
        text.textSize = radius * 0.24f
        val flick = if (rnd.nextFloat() < 0.04f) 0.15f else 1f
        val a = ((120 + 80 * sin(t * 2f)) * flick).toInt().coerceIn(0, 255)
        text.color = Color.argb(a, 200, 20, 20)
        text.clearShadowLayer()
        text.letterSpacing = 0.25f
        c.drawText("DON'T PRESS", cx, cy + radius * 1.32f + radius * 0.55f, text)
        text.letterSpacing = 0f
    }

    // ------------------------------------------------------- face scan

    private fun withAlpha(col: Int, a: Int) = (col and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    /** Wireframe face + mesh, drawn only above [limitY]. */
    private fun drawFaceWire(c: Canvas, col: Int, a: Int, limitY: Float) {
        val r = radius
        c.save()
        c.clipRect(cx - r * 3f, cy - r * 3f, cx + r * 3f, limitY)
        headRect.set(cx - r * 0.95f, cy - r * 1.3f, cx + r * 0.95f, cy + r * 1.3f)

        // mesh grid clipped to the head
        c.save()
        path.reset(); path.addOval(headRect, Path.Direction.CW)
        c.clipPath(path)
        line.strokeWidth = r * 0.012f
        line.color = withAlpha(col, a / 3)
        var g = -1.2f
        while (g <= 1.21f) {
            c.drawLine(cx - r, cy + g * r, cx + r, cy + g * r, line)
            c.drawLine(cx + g * r * 0.8f, cy - r * 1.4f, cx + g * r * 0.8f, cy + r * 1.4f, line)
            g += 0.3f
        }
        c.restore()

        line.strokeWidth = r * 0.035f
        line.color = withAlpha(col, a)
        c.drawOval(headRect, line)
        // eyes
        for (sgn in floatArrayOf(-1f, 1f)) {
            tmpRect.set(cx + sgn * r * 0.38f - r * 0.2f, cy - r * 0.3f - r * 0.09f,
                cx + sgn * r * 0.38f + r * 0.2f, cy - r * 0.3f + r * 0.09f)
            c.drawOval(tmpRect, line)
            c.drawLine(cx + sgn * r * 0.2f, cy - r * 0.56f, cx + sgn * r * 0.62f, cy - r * 0.6f, line)
        }
        // nose
        path.reset()
        path.moveTo(cx, cy - r * 0.2f)
        path.lineTo(cx - r * 0.1f, cy + r * 0.35f)
        path.lineTo(cx + r * 0.12f, cy + r * 0.35f)
        c.drawPath(path, line)
        // mouth
        tmpRect.set(cx - r * 0.38f, cy + r * 0.45f, cx + r * 0.38f, cy + r * 0.9f)
        c.drawArc(tmpRect, 20f, 140f, false, line)
        c.restore()
    }

    private fun drawBrackets(c: Canvas, col: Int, a: Int, grow: Float) {
        val hw = radius * (1.65f + grow)
        val hh = radius * (1.85f + grow)
        val len = radius * 0.45f
        line.strokeWidth = radius * 0.05f
        line.color = withAlpha(col, a)
        val xs = floatArrayOf(-hw, hw); val ys = floatArrayOf(-hh, hh)
        for (sx in xs) for (sy in ys) {
            val dx = if (sx < 0) len else -len
            val dy = if (sy < 0) len else -len
            c.drawLine(cx + sx, cy + sy, cx + sx + dx, cy + sy, line)
            c.drawLine(cx + sx, cy + sy, cx + sx, cy + sy + dy, line)
        }
    }

    private fun drawStatus(c: Canvas, s: String, col: Int, alpha: Int, scale: Float = 1f) {
        val u = min(radius * 0.05f, width * 0.9f / pixelWidth(s, 1f)) * scale
        val tw = pixelWidth(s, u)
        val top = cy + radius * 2.15f
        drawPixelText(c, s, cx - tw / 2f, top, u, withAlpha(col, alpha / 4), u * 0.45f)
        drawPixelText(c, s, cx - tw / 2f, top, u, withAlpha(col, alpha))
    }

    private fun drawScan(c: Canvas, now: Long) {
        val p = ((now - phaseStart) / scanDur.toFloat()).coerceIn(0f, 1f)
        val r = radius

        // dim the red button so the scan reads clearly on top of it
        overlay.color = Color.argb(205, 0, 0, 0)
        c.drawCircle(cx, cy, r * 1.3f, overlay)

        val pulse = (0.5f + 0.5f * sin(now / 120.0)).toFloat()
        drawBrackets(c, cyan, 200 + (55 * pulse).toInt(), (1f - p.coerceAtMost(0.3f) / 0.3f) * 0.35f)

        // two sweeps: down (reveals the face) and back up (locks on)
        val q = p * 2f
        val frac = if (q < 1f) q else 2f - q
        val topY = cy - r * 1.6f
        val botY = cy + r * 1.6f
        val scanY = topY + (botY - topY) * frac

        drawFaceWire(c, cyan, 60, height * 2f)                       // faint whole face
        drawFaceWire(c, cyan, 255, if (p < 0.5f) scanY else height * 2f)

        // landmark points pop in as the scanner passes them
        for ((i, lm) in landmarks.withIndex()) {
            val y = cy + lm[1] * r
            if (p < 0.5f && y > scanY) continue
            val tw = 0.7f + 0.3f * sin(now / 150.0 + i).toFloat()
            dot.color = Color.WHITE
            c.drawCircle(cx + lm[0] * r, y, r * 0.035f * tw, dot)
            dot.color = withAlpha(cyan, 90)
            c.drawCircle(cx + lm[0] * r, y, r * 0.075f * tw, dot)
        }

        // scan beam
        val bh = r * 0.28f
        dot.shader = LinearGradient(
            0f, scanY - bh, 0f, scanY + bh,
            intArrayOf(Color.TRANSPARENT, withAlpha(cyan, 170), Color.WHITE, withAlpha(cyan, 170), Color.TRANSPARENT),
            floatArrayOf(0f, 0.4f, 0.5f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(cx - r * 1.5f, scanY - bh, cx + r * 1.5f, scanY + bh, dot)
        dot.shader = null

        // status text
        val dots = ".".repeat(((now / 350) % 4).toInt())
        drawStatus(c, "SCANNING FACE", cyan, 235)
        text.typeface = mono
        text.textSize = r * 0.14f
        text.letterSpacing = 0.15f
        text.color = withAlpha(cyan, 190)
        val msg = scanLines[(p * scanLines.size).toInt().coerceIn(0, scanLines.size - 1)]
        c.drawText(msg + dots, cx, cy + r * 2.15f + r * 0.05f * 7f + r * 0.35f, text)
        text.letterSpacing = 0f
    }

    private fun drawVerified(c: Canvas, now: Long) {
        val since = now - phaseStart
        val r = radius
        val k = (since / 450f).coerceIn(0f, 1f)

        overlay.color = Color.argb(205, 0, 0, 0)
        c.drawCircle(cx, cy, r * 1.3f, overlay)

        drawBrackets(c, green, 255, 0f)
        drawFaceWire(c, green, 90, height * 2f)

        // ring + check mark drawing itself
        line.strokeWidth = r * 0.09f
        line.color = withAlpha(green, 255)
        tmpRect.set(cx - r * 0.8f, cy - r * 0.8f, cx + r * 0.8f, cy + r * 0.8f)
        c.drawArc(tmpRect, -90f, 360f * k, false, line)
        val tk = ((since - 250f) / 350f).coerceIn(0f, 1f)
        if (tk > 0f) {
            val x0 = cx - r * 0.38f; val y0 = cy + r * 0.02f
            val x1 = cx - r * 0.1f;  val y1 = cy + r * 0.3f
            val x2 = cx + r * 0.42f; val y2 = cy - r * 0.28f
            path.reset()
            path.moveTo(x0, y0)
            if (tk < 0.4f) {
                val f = tk / 0.4f
                path.lineTo(x0 + (x1 - x0) * f, y0 + (y1 - y0) * f)
            } else {
                val f = (tk - 0.4f) / 0.6f
                path.lineTo(x1, y1)
                path.lineTo(x1 + (x2 - x1) * f, y1 + (y2 - y1) * f)
            }
            c.drawPath(path, line)
        }

        val sl = if (since < 350) 1.25f - 0.25f * (since / 350f) else 1f
        drawStatus(c, "FACE VERIFIED", green, (k * 255).toInt(), sl)
        text.typeface = mono
        text.textSize = r * 0.14f
        text.letterSpacing = 0.15f
        text.color = withAlpha(green, (190 * k).toInt())
        c.drawText("IDENTITY CONFIRMED", cx, cy + r * 2.15f + r * 0.05f * 7f + r * 0.35f, text)
        text.letterSpacing = 0f
    }

    private fun drawActivated(c: Canvas, now: Long, since: Long) {
        val s = "ACTIVATED"
        // sized to the screen and placed at the exact centre
        val u = min(width * 0.86f / pixelWidth(s, 1f), height * 0.2f / 7f)
        val tw = pixelWidth(s, u)
        val top = (height - 7f * u) / 2f
        var left = cx - tw / 2f

        // slam-in scale
        val k = (since / 350f).coerceIn(0f, 1f)
        val sc = if (k < 1f) 2.2f - 1.2f * k * k * (3f - 2f * k) else 1f
        val alpha = (k * 255).toInt()

        // glitchy jitter right after activation, occasional twitch later
        var jx = 0f
        var split = 0f
        if (since < 900) {
            val d = 1f - since / 900f
            jx = (rnd.nextFloat() - 0.5f) * 2f * u * 2.5f * d
            split = u * 1.2f * d * rnd.nextFloat()
        } else if (rnd.nextFloat() < 0.02f) {
            jx = (rnd.nextFloat() - 0.5f) * 2f * u * 1.5f
            split = u * 0.8f
        }
        left += jx

        c.save()
        c.scale(sc, sc, width / 2f, height / 2f)

        // soft green glow
        drawPixelText(c, s, left, top, u, Color.argb(alpha * 28 / 255, 40, 255, 90), u * 1.1f)
        drawPixelText(c, s, left, top, u, Color.argb(alpha * 50 / 255, 40, 255, 90), u * 0.5f)
        if (split > 0f) {
            drawPixelText(c, s, left - split, top, u, Color.argb(alpha * 130 / 255, 0, 255, 230))
            drawPixelText(c, s, left + split, top, u, Color.argb(alpha * 130 / 255, 255, 0, 40))
        }
        drawPixelText(c, s, left, top, u, Color.argb(alpha, 40, 255, 90))
        c.restore()

        // tiny hint
        if (since > 3500) {
            text.typeface = mono
            text.textSize = radius * 0.13f
            text.letterSpacing = 0.2f
            text.color = Color.argb((60 + 40 * sin(now / 400.0)).toInt(), 200, 40, 40)
            c.drawText("tap anywhere to wake it again", cx, height - radius * 0.2f, text)
            text.letterSpacing = 0f
        }
    }
}
