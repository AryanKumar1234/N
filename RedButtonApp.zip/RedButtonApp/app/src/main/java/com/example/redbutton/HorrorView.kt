package com.example.redbutton

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Whole horror loading screen drawn on one Canvas.
 * Everything is computed from the view's width/height, so it works in
 * portrait and landscape without any extra layout files.
 */
class HorrorView(context: Context) : View(context) {

    private enum class State { IDLE, LOADING, DONE }

    private var state = State.IDLE
    private var progress = 0f            // 0..1
    private var doneAt = 0L
    private var pressed = false
    private val startTime = SystemClock.uptimeMillis()
    private val rnd = Random(666)

    private var animator: ValueAnimator? = null

    // geometry
    private var cx = 0f
    private var cy = 0f
    private var radius = 0f

    // paints
    private val bg = Paint()
    private val vignette = Paint()
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val face = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val ringBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val dripPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND; color = Color.rgb(150, 0, 0)
    }
    private val overlay = Paint()
    private val dust = Paint(Paint.ANTI_ALIAS_FLAG)

    private val serifBold = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
    private val mono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    private class Drip(val xf: Float, val maxLen: Float, val w: Float, val delay: Long, val dur: Long)
    private var drips: List<Drip> = emptyList()

    private class Mote(val x: Float, val y: Float, val speed: Float, val size: Float, val phase: Float)
    private var motes: List<Mote> = emptyList()

    private val lines = arrayOf(
        "SOMETHING IS WAKING...",
        "IT CAN HEAR YOU...",
        "DON'T LOOK BEHIND YOU...",
        "IT'S ALMOST HERE...",
        "TOO LATE."
    )

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cx = w / 2f
        cy = h * 0.40f
        radius = min(w * 0.22f, h * 0.20f)

        vignette.shader = RadialGradient(
            w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) / 2f,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(235, 0, 0, 0)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        bg.shader = RadialGradient(
            cx, cy, hypot(w.toFloat(), h.toFloat()) * 0.6f,
            intArrayOf(Color.rgb(38, 0, 0), Color.rgb(8, 0, 0), Color.BLACK),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        face.shader = RadialGradient(
            cx - radius * 0.3f, cy - radius * 0.35f, radius * 1.25f,
            intArrayOf(Color.rgb(255, 70, 60), Color.rgb(200, 0, 0), Color.rgb(90, 0, 0)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        rim.shader = LinearGradient(
            cx, cy - radius, cx, cy + radius * 1.15f,
            Color.rgb(70, 70, 70), Color.rgb(8, 8, 8), Shader.TileMode.CLAMP
        )
        shine.shader = LinearGradient(
            cx, cy - radius * 0.9f, cx, cy,
            Color.argb(150, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )

        motes = List(40) {
            Mote(rnd.nextFloat(), rnd.nextFloat(), 0.01f + rnd.nextFloat() * 0.04f,
                1f + rnd.nextFloat() * 2.5f, rnd.nextFloat() * 6.28f)
        }
        buildDrips()
    }

    private fun activatedSize(): Float {
        val w = width.toFloat()
        val h = height.toFloat()
        text.typeface = serifBold
        text.textSize = 100f
        val base = text.measureText("ACTIVATED")
        val fitW = 100f * (w * 0.90f) / base
        val fitH = (h - (cy + radius)) * 0.34f
        return min(fitW, fitH).coerceAtLeast(24f)
    }

    private fun buildDrips() {
        val size = activatedSize()
        text.textSize = size
        val tw = text.measureText("ACTIVATED")
        val avail = height - textBaseline(size) - size * 0.15f
        drips = List(11) { i ->
            val xf = (i + 0.3f + rnd.nextFloat() * 0.5f) / 11f
            Drip(
                xf = xf,
                maxLen = (size * 0.25f + rnd.nextFloat() * size * 0.95f).coerceAtMost(avail.coerceAtLeast(size * 0.2f)),
                w = size * (0.045f + rnd.nextFloat() * 0.04f),
                delay = 300L + rnd.nextLong(1400),
                dur = 1600L + rnd.nextLong(2600)
            )
        }
        @Suppress("UNUSED_VARIABLE") val unused = tw
    }

    private fun textBaseline(size: Float) = cy + radius + 0.28f * radius + size

    // ---------------------------------------------------------------- touch

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val inside = hypot(e.x - cx, e.y - cy) <= radius * 1.15f
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (inside) { pressed = true; invalidate(); return true }
                return false
            }
            MotionEvent.ACTION_UP -> {
                val wasPressed = pressed
                pressed = false
                if (wasPressed && inside) {
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    when (state) {
                        State.IDLE -> startLoading()
                        State.DONE -> reset()
                        else -> {}
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { pressed = false; invalidate() }
        }
        return true
    }

    private fun startLoading() {
        state = State.LOADING
        progress = 0f
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 5000L
            interpolator = LinearInterpolator()
            addUpdateListener { progress = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) {
                    if (cancelled) return
                    progress = 1f
                    state = State.DONE
                    doneAt = SystemClock.uptimeMillis()
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                }
            })
            start()
        }
    }

    private fun reset() {
        animator?.cancel()
        state = State.IDLE
        progress = 0f
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    // ----------------------------------------------------------------- draw

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = (now - startTime) / 1000f
        val w = width.toFloat()
        val h = height.toFloat()

        // shake grows while loading, big slam when activated
        var sx = 0f
        var sy = 0f
        val sinceDone = if (state == State.DONE) now - doneAt else Long.MAX_VALUE
        val shake = when (state) {
            State.LOADING -> progress * progress * radius * 0.05f
            State.DONE -> if (sinceDone < 700) radius * 0.12f * (1f - sinceDone / 700f) else 0f
            else -> 0f
        }
        if (shake > 0f) { sx = (rnd.nextFloat() - 0.5f) * 2f * shake; sy = (rnd.nextFloat() - 0.5f) * 2f * shake }

        c.drawRect(0f, 0f, w, h, bg)

        c.save()
        c.translate(sx, sy)

        drawMotes(c, t, w, h)
        drawButton(c, t)
        drawRing(c)
        when (state) {
            State.IDLE -> drawIdleText(c, t)
            State.LOADING -> drawLoadingText(c, t)
            State.DONE -> drawActivated(c, now, sinceDone)
        }
        c.restore()

        // vignette
        c.drawRect(0f, 0f, w, h, vignette)

        // flicker – occasional dark/red flashes, more frequent as progress rises
        val chance = when (state) { State.IDLE -> 0.012f; State.LOADING -> 0.02f + progress * 0.10f; else -> 0.015f }
        if (rnd.nextFloat() < chance) {
            overlay.color = if (rnd.nextBoolean()) Color.argb(rnd.nextInt(60, 150), 0, 0, 0)
            else Color.argb(rnd.nextInt(20, 60), 255, 0, 0)
            c.drawRect(0f, 0f, w, h, overlay)
        }
        // activation flash
        if (state == State.DONE && sinceDone < 450) {
            overlay.color = Color.argb((200 * (1f - sinceDone / 450f)).toInt(), 255, 20, 10)
            c.drawRect(0f, 0f, w, h, overlay)
        }
        // scanlines
        overlay.color = Color.argb(28, 0, 0, 0)
        var y = 0f
        while (y < h) { c.drawRect(0f, y, w, y + 1.5f, overlay); y += 5f }

        postInvalidateOnAnimation()
    }

    private fun drawMotes(c: Canvas, t: Float, w: Float, h: Float) {
        for (m in motes) {
            val yy = ((m.y - t * m.speed) % 1f + 1f) % 1f
            val xx = m.x + sin(t * 0.6f + m.phase) * 0.02f
            val a = (40 + 40 * sin(t * 1.3f + m.phase)).toInt().coerceIn(5, 90)
            dust.color = Color.argb(a, 200, 30, 20)
            c.drawCircle(xx * w, yy * h, m.size, dust)
        }
    }

    private fun drawButton(c: Canvas, t: Float) {
        // heartbeat: two quick beats, faster while loading
        val bpm = if (state == State.LOADING) 70f + 110f * progress else 54f
        val ph = (t * bpm / 60f) % 1f
        val beat = when {
            ph < 0.10f -> sin(ph / 0.10f * PI).toFloat()
            ph in 0.18f..0.30f -> 0.6f * sin((ph - 0.18f) / 0.12f * PI).toFloat()
            else -> 0f
        }
        val intensity = when (state) { State.IDLE -> 0.6f; State.LOADING -> 0.8f + progress * 0.4f; else -> 1.2f }
        val scale = (if (pressed) 0.93f else 1f) + beat * 0.035f

        // glow
        val gr = radius * (1.9f + beat * 0.35f)
        glow.shader = RadialGradient(
            cx, cy, gr,
            intArrayOf(Color.argb((170 * intensity).toInt().coerceAtMost(255), 255, 0, 0),
                Color.argb((60 * intensity).toInt(), 160, 0, 0), Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, gr, glow)

        c.save()
        c.scale(scale, scale, cx, cy)
        // metal base
        c.drawCircle(cx, cy, radius * 1.12f, rim)
        overlay.color = Color.BLACK
        c.drawCircle(cx, cy, radius * 1.02f, overlay)
        // red face
        c.drawCircle(cx, cy, radius * (if (pressed) 0.90f else 0.96f), face)
        // gloss
        val rr = radius * 0.72f
        c.drawOval(RectF(cx - rr, cy - radius * 0.88f, cx + rr, cy - radius * 0.18f), shine)
        c.restore()
    }

    private fun drawRing(c: Canvas) {
        val r = radius * 1.32f
        val sw = radius * 0.07f
        ringBg.strokeWidth = sw
        ringBg.color = Color.argb(60, 255, 0, 0)
        if (state == State.IDLE) return
        c.drawCircle(cx, cy, r, ringBg)
        ring.strokeWidth = sw
        ring.color = Color.rgb(220, 10, 10)
        c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * progress, false, ring)
    }

    private fun drawIdleText(c: Canvas, t: Float) {
        text.typeface = mono
        text.textSize = radius * 0.24f
        val flick = if (rnd.nextFloat() < 0.04f) 0.15f else 1f
        val a = ((120 + 80 * sin(t * 2f)) * flick).toInt().coerceIn(0, 255)
        text.color = Color.argb(a, 200, 20, 20)
        text.clearShadowLayer()
        text.letterSpacing = 0.25f
        c.drawText("DON'T PRESS", cx, cy + radius * 1.32f + radius * 0.55f, text)
        text.letterSpacing = 0f
    }

    private fun drawLoadingText(c: Canvas, t: Float) {
        val pct = (progress * 100f).toInt()
        val base = cy + radius * 1.32f + radius * 0.62f
        text.typeface = serifBold
        text.textSize = radius * 0.62f
        text.color = Color.rgb(210, 10, 10)
        text.setShadowLayer(radius * 0.18f, 0f, 0f, Color.argb(220, 255, 0, 0))
        val jx = if (rnd.nextFloat() < progress * 0.3f) (rnd.nextFloat() - 0.5f) * radius * 0.1f else 0f
        c.drawText("$pct%", cx + jx, base, text)
        text.clearShadowLayer()

        text.typeface = mono
        text.textSize = radius * 0.17f
        text.letterSpacing = 0.15f
        text.color = Color.argb(200, 170, 20, 20)
        val idx = (progress * lines.size).toInt().coerceIn(0, lines.size - 1)
        c.drawText(lines[idx], cx, base + radius * 0.32f, text)
        text.letterSpacing = 0f
    }

    private fun drawActivated(c: Canvas, now: Long, since: Long) {
        val size = activatedSize()
        val base = textBaseline(size)
        // slam-in scale
        val k = (since / 350f).coerceIn(0f, 1f)
        val s = if (k < 1f) 2.2f - 1.2f * k * k * (3f - 2f * k) else 1f

        text.typeface = serifBold
        text.textSize = size
        val tw = text.measureText("ACTIVATED")
        val left = cx - tw / 2f

        c.save()
        c.scale(s, s, cx, base - size * 0.35f)
        val alpha = (k * 255).toInt()

        // drips first (behind letters), hanging from the baseline area
        for (d in drips) {
            val p = ((since - d.delay) / d.dur.toFloat()).coerceIn(0f, 1f)
            if (p <= 0f) continue
            val e = 1f - (1f - p) * (1f - p) * (1f - p)
            val len = d.maxLen * e
            val x = left + tw * d.xf
            val top = base - size * 0.12f
            dripPaint.strokeWidth = d.w
            dripPaint.alpha = alpha
            c.drawLine(x, top, x, top + len, dripPaint)
            c.drawCircle(x, top + len, d.w * 0.95f, dripPaint)
        }

        // blood glow + outline + gradient fill
        text.style = Paint.Style.FILL
        text.shader = null
        text.color = Color.argb(alpha, 120, 0, 0)
        text.setShadowLayer(size * 0.35f, 0f, size * 0.04f, Color.argb(alpha, 255, 0, 0))
        c.drawText("ACTIVATED", cx, base, text)
        text.clearShadowLayer()

        text.style = Paint.Style.STROKE
        text.strokeWidth = size * 0.07f
        text.strokeJoin = Paint.Join.ROUND
        text.color = Color.argb(alpha, 25, 0, 0)
        c.drawText("ACTIVATED", cx, base, text)

        text.style = Paint.Style.FILL
        text.shader = LinearGradient(
            0f, base - size * 0.8f, 0f, base + size * 0.05f,
            intArrayOf(Color.rgb(255, 40, 30), Color.rgb(190, 0, 0), Color.rgb(85, 0, 0)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        text.alpha = alpha
        c.drawText("ACTIVATED", cx, base, text)
        text.shader = null

        // wet highlights
        text.color = Color.argb((alpha * 0.18f).toInt(), 255, 200, 190)
        text.textSize = size
        c.save()
        c.clipRect(0f, base - size * 0.85f, w(), base - size * 0.5f)
        c.drawText("ACTIVATED", cx, base, text)
        c.restore()
        c.restore()

        // tiny hint
        if (since > 3500) {
            text.typeface = mono
            text.textSize = radius * 0.13f
            text.letterSpacing = 0.2f
            text.color = Color.argb((60 + 40 * sin(now / 400.0)).toInt(), 200, 40, 40)
            c.drawText("tap the button to wake it again", cx, height - radius * 0.2f, text)
            text.letterSpacing = 0f
        }
    }

    private fun w() = width.toFloat()
}
